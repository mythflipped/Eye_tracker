import cv2
import numpy as np
import camera_configs

# these are coordinates of left eye and right eye
# pls set them true value
# setting them 0 is just a test
x_left = 0
y_left = 0
x_right = 0
y_right = 0


# 添加点击事件，打印当前点的距离
def callbackFunc(e, x, y, f, p):
    if e == cv2.EVENT_LBUTTONDOWN:
        print(threeD[y][x])


cv2.namedWindow("left")
cv2.namedWindow("right")
cv2.namedWindow("depth")
cv2.createTrackbar("num", "depth", 0, 10, lambda x: None)
cv2.createTrackbar("blockSize", "depth", 5, 255, lambda x: None)
cap_left = cv2.VideoCapture(1)
cap_right = cv2.VideoCapture(2)

while True:
    ret_left, frame_left = cap_left.read()
    ret_right, frame_right = cap_right.read()

    if not ret_left or not ret_right:
        break

    # 根据更正map对图片进行重构
    frame_left_rectified = cv2.remap(frame_left, camera_configs.left_map1, camera_configs.left_map2,cv2.INTER_LINEAR)
    frame_right_rectified = cv2.remap(frame_right, camera_configs.right_map1, camera_configs.right_map2,cv2.INTER_LINEAR)

    # 调灰度(没用重构的）
    frame_left_gray = cv2.cvtColor(frame_left_rectified, cv2.COLOR_BGR2GRAY)
    frame_right_gray = cv2.cvtColor(frame_right_rectified, cv2.COLOR_BGR2GRAY)

    # 两个trackbar用来调节不同的参数查看效果
    num = cv2.getTrackbarPos("num", "depth")
    blockSize = cv2.getTrackbarPos("blockSize", "depth")
    if blockSize % 2 == 0:
        blockSize += 1
    if blockSize < 5:
        blockSize = 5

    # 根据BM(Block Maching)方法生成差异图
    stereo = cv2.StereoBM_create(numDisparities=16*num, blockSize=blockSize)
    disparity = stereo.compute(frame_left_gray, frame_right_gray)
    disp = cv2.normalize(disparity, disparity, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    threeD = cv2.reprojectImageTo3D(disparity.astype(np.float32) / 16., camera_configs.Q)
    frame = np.hstack((frame_left_rectified, frame_right_rectified))
    cv2.imshow('RGB+IR', frame)
    cv2.imshow('深度图', disp)
    print('left_eye', threeD[y_left][x_left])
    print('right_eye', threeD[y_right][x_right])
    print(threeD)

    k = cv2.waitKey(1)
    if k == ord('q'):
        break

cap_left.release()
cap_right.release()
cv2.destroyAllWindows()



