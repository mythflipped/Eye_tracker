for kk = 1:n_ima,
   eval(['clear wintx_' num2str(kk)]);
   eval(['clear winty_' num2str(kk)]);
end;
