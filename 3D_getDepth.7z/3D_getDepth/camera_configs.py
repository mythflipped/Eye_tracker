import cv2
import numpy as np

left_camera_matrix = np.array([[759.4370, 0., 320.0337],
                               [0., 752.8790, 237.1215],
                               [0., 0., 1.]])
left_distortion = np.array([[0.0181, -0.0665, 0.0000, 0.0000, 0.0000]])


right_camera_matrix = np.array([[754.9774, 0., 320.3209],
                                [0., 748.4700, 239.3558],
                                [0., 0., 1.]])
right_distortion = np.array([[0.0066, -0.0091, 0.0000, 0.0000, 0.0000]])

om = np.array([0.0014, 0.0044, 0.0010]) # 旋转关系向量
R = cv2.Rodrigues(om)[0]  # 使用Rodrigues变换将om变换为R
T = np.array([13.5076, 0.3824, -3.6864]) # 平移关系向量

size = (640, 480) # 图像尺寸

# 进行立体更正
R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
                                                                  right_camera_matrix, right_distortion, size, R,
                                                                  T)
# 计算更正map
left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)

